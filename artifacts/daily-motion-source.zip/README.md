# 每日动一动 · 安卓个人运动与饮食监督

找不到上次聊天记录时，先看 [当前进度与继续步骤](PROJECT-STATUS.md)。电脑预览可双击 `start-preview.cmd` 启动，再打开 <http://127.0.0.1:8787>。

给本人使用的中文、本地优先应用，无需注册应用账号。默认目标为“减脂，同时保持肌肉”，具体热量和蛋白质数值由本人设置。设备已确认是华为 Mate 60 Pro、HarmonyOS 4.2.0.198，继续使用安卓 APK。用户已试用上一版，本轮根据反馈补充整周计划导入与更新流程。

当前版本 0.2.0，版本码 3；安装包路径为 `artifacts/daily-motion-0.2.0-debug.apk`。本轮最终构建、签名和测试结果见 [VALIDATION.md](VALIDATION.md)，手机新增功能、系统语音及后台提醒仍需本人验收。安装见 [INSTALL-ANDROID.md](INSTALL-ANDROID.md)，更新方式见 [UPDATE.md](UPDATE.md)，变化见 [CHANGELOG.md](CHANGELOG.md)。

## 当前能用什么

- 一次粘贴整周文字计划，预览按星期和运动项目拆分的结果，再统一导入；可选每周重复或仅安排所选一周。
- 每天每项运动独立勾选完成、撤销或记录跳过原因；组数、重量、实际时长为选填。可查看未来安排，未来日期不能提前勾完成。
- 每周重复计划会补入已浏览过的未来日期；仅该周导入只影响所选周。导入保留已有打卡、饮食和历史记录，并跳过相同项目。
- 常吃食物、常用份量、最近饮食一键复用、复制昨天饮食，以及热量和蛋白质汇总。
- 系统中文语音入口、文字匹配食物与份量确认；未知食物留待补全，不猜热量。系统语音需真机验证，浏览器可用输入法语音或文字。
- 首页结合当天已记录摄入、自设目标及前两天的训练勾选给出提醒；饮食未记全时显示记录进度，不判断全天摄入不足。
- 原生强提醒文案显示具体待完成项目和当天饮食进度，保留声音/振动、有限次复提醒、稍后提醒、夜间静默、重启恢复和完成后停止。
- 安装自检、近 7 天回顾、体重与感受、JSON 备份恢复，以及未保存输入和旧 WebView 兼容处理。

WHOOP 和 Health Connect 同步已按本轮要求暂停，界面没有授权、连接或同步入口，也不自动请求数据。原模块和已有缓存保留，当前使用本机记录。无需创建 WHOOP 开发者应用或部署同步服务。

项目参考与功能取舍见 [RESEARCH.md](RESEARCH.md)、[第一版开发要求](V1-REQUIREMENTS.md)、[审查与改进](APP-REVIEW.md) 和 [完整项目目录](PROJECT-TREE.md)。浏览器预览不能提供关闭页面后的手机系统提醒；拍照识别、条码库、应用内在线更新和远程热更新尚未实现。

## 立即预览

需要 Node.js 22+，运行应用无需安装 npm 依赖。在本目录运行：

```powershell
node server.mjs
```

在电脑打开 <http://127.0.0.1:8787>，可调整浏览器到手机尺寸。首次使用先到“训练”导入整周计划，在“饮食”创建常吃食物，在“设置”填个人目标。浏览器与安卓的数据不自动互通，可用 JSON 备份转移。

预览默认只监听本机，不自动部署到公网。手机安装请使用 APK。

## 导入一周计划

在“训练”选择整周计划导入，将聊天或备忘录中的文字粘贴进去。支持“周一 / 星期一”等分组及 Markdown 项目列表。每天每个动作单独一行最容易确认；组数与次数保留为项目说明，不会当成分钟数。

下面仅演示格式，不代表建议采用这组训练：

```text
周一
- 卧推 3组×10次
- 快走 20分钟
周二
- 休息
```

选择起始周和“每周重复”或“仅该周”，先预览每一天拆出的项目，修正没有识别的内容，再确认导入。导入不会代替本人确认动作完成；当天打开后逐项勾选即可。

## 构建与以后更新

项目在 `android/`，使用 Android 平台 Java API 与 APK 内的本地界面，无远程页面、无需第三方运行时 UI 库。最低 Android 8.0；界面仍需要支持 ES modules 等语法的较新 WebView，缺少 structuredClone 和 dialog 方法已有轻量回退。

构建要求：JDK 17、Android SDK Platform 35、Build Tools 35.0.0、Gradle 8.11.1。项目使用 AGP 8.10.1，兼容关系见 [AGP 8.10 官方兼容表](https://developer.android.com/build/releases/agp-8-10-0-release-notes)。

1. 配置 JDK / SDK，或复用项目 `private/tooling/` 的便携工具；SDK 也可在 `android/local.properties` 指定。
2. 在项目根目录运行构建脚本：

```powershell
powershell -ExecutionPolicy Bypass -File .\build-android.ps1
```

也可使用带固定校验值的 wrapper：`android\gradlew.bat -p android assembleDebug`。产物为 `android/app/build/outputs/apk/debug/app-debug.apk`。

日后继续修改同一个项目，用 [make-update.ps1](make-update.ps1) 准备更新包，具体参数与步骤见 [UPDATE.md](UPDATE.md)。版本号递增、应用标识和签名一致时，打开新版 APK 按系统提示覆盖更新即可，训练与饮食记录留在原应用中，无需重做一个软件。目前需要本人手动下载或接收更新包、确认系统安装，尚无应用内在线更新或远程热更新。

测试签名保存在 `private/signing/personal-debug.keystore`，首次构建脚本仅在密钥缺失时创建，不轮换现有密钥。请保留这份私有文件，不覆盖或放进分享包。当前是个人测试包，正式发布签名暂未配置。

另有 `.github/workflows/android.yml` 可在自己的 GitHub 仓库手动构建；本次未上传或运行。普通 CI 默认生成的测试签名可能与本机不同；保持覆盖更新前应核对签名，不能用不同签名的包直接替换现有应用。

## 安卓使用与提醒

在“设置”启用提醒并保存，允许系统通知，可选授权精准提醒。每日训练与饮食检查默认 18:30 / 20:30，每类每天最多 3 次（含首次）、未完成后间隔 30 分钟，默认 22:30–07:00 静默。检查时间需要在静默时段外。动作计划时间目前仅展示，不是每项独立闹钟。

通知会参考今日待确认项目、当天已记录热量和蛋白质，以及前两天训练勾选。记录缺失时不当作漏练，不按设备消耗自动增加饮食目标，不要求加练抵消饮食。训练完成或明确跳过后停止相应提醒；饮食记全且没有待补全备注后停止饮食提醒。

原生提醒不依赖 WebView 持续打开。手机省电、勿扰和权限可能阻止或延迟提醒，系统强行停止后需重新打开。华为须检查应用启动管理与后台活动；详细真机验收见 [REMINDERS_TEST_PLAN.md](android/REMINDERS_TEST_PLAN.md)。

训练和饮食保存在应用私有 SharedPreferences JSON。Android 系统云备份关闭，没有分析 SDK，当前没有额外数据库加密或生物识别锁。可用系统文件选择器导出/恢复 JSON；备份含健康记录且不加密，请自行保管。卸载或清除数据会移除本机记录，更新前可先导出备份。

## WHOOP 技术资料（暂停）

现有服务端、配置向导和健康数据模块保留供后续扩展；本轮不继续开通、部署或验收真实同步，也不列为使用前提。此前方案见 [WHOOP-SYNC.md](WHOOP-SYNC.md) 与 [WHOOP-SETUP.md](WHOOP-SETUP.md)，其中连接操作不适用于当前已暂停同步的界面。原缓存未删除，不代表新版本正在持续获取数据。

## 验证

```powershell
node --test test/*.test.mjs
npm ci
node test/ui-smoke.mjs
node test/ui-audit.mjs
node test/ui-readiness.mjs
node test/verify-apk.mjs artifacts/daily-motion-0.2.0-debug.apk
```

最终检查项目和计数以 [VALIDATION.md](VALIDATION.md) 为准。手机尺寸测试通过开发依赖 playwright-core 使用已安装 Chrome，不下载浏览器；默认 `C:\Program Files\Google\Chrome\Application\chrome.exe`，可用 `CHROME_PATH` 改路径。测试使用隔离上下文，不读日常浏览器数据；测试食物数值仅供交互验证。

真机仍需验证：覆盖安装后保留记录、整周计划导入与逐项勾选、系统中文语音、通知允许/拒绝、锁屏后台、跨日、重启、静默、强行停止后重新打开及文件备份恢复。浏览器模拟、本机编译和签名校验不能替代这些结果。

## 目录

- `web/`：共享交互界面、计划导入、饮食与本地反馈规则。
- `android/`：本地 WebView、私有存储、系统文件选择器、语音与提醒。
- `server.mjs`、`whoop.mjs`：本机预览与已暂停使用的可选同步模块。
- `test/`：业务、保留模块及手机尺寸交互检查。
- `make-update.ps1`、`UPDATE.md`：同一项目的后续更新流程。

完整目录、模块责任和发布包排除项见 [PROJECT-TREE.md](PROJECT-TREE.md)。本项目没有复制调研项目代码或素材；后续直接合并开源实现时需按对应许可处理。